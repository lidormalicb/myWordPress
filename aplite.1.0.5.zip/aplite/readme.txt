License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
AccessPress Lite WordPress Theme, Copyright 2015 http://wordpresssuperexpress.com
AccessPress Lite is distributed under the terms of the GNU GPL v3


== Install Steps ==
1. Activate the theme
2. Go to the Theme Option page
3. Setup theme options

== Description ==
Aplite Reload is a child theme of AccessPress Lite Theme.


== Changelog ==
= 1.0.5 =
* RTL CSS fixes

= 1.0.4 =
* Slider Caption vertical Alignment fixed
* Google Font Issue Fixed

= 1.0.2 =
* Minor Fixes(footer link, header image, translation)

= 1.0 =
* Theme Release


== Resources ==
* Footer Background Image
http://www.pexels.com/photo/apple-imac-close-up-of-monitor-mouse-and-keyboard-6415/