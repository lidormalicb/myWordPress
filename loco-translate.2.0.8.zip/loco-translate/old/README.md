# Legacy version

The final release of 1.x bundled into 2.x

You can switch between branches by setting the site option `loco-branch` to either `"1"` or `"2"`.