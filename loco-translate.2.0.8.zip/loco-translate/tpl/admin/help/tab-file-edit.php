<h2>
    The translation editor
</h2>
<p>
    This editor allows you to translate and save strings to your server's file system in the correct file format.
</p>
<p>
    <a href="<?php echo esc_url(apply_filters('loco_external','https://localise.biz/wordpress/plugin/manual/editor'))?>" target="_blank">Full documentation</a>
</p>