<?php
/**
 * Just for testing autoloader
 */
interface DummyInterface {
    
}
