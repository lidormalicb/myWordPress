<?php if(!defined('ABSPATH')) { die('You are not allowed to call this page directly.'); } ?>
<h2 id="prli_title" style="margin: 10px 0px 0px 0px; padding: 0px 0px 0px 169px; height: 64px; background: url(<?php echo PRLI_IMAGES_URL; ?>/prettylink_logo_64.jpg) no-repeat">&nbsp;&nbsp;<?php echo esc_html($page_title); ?></h2>
