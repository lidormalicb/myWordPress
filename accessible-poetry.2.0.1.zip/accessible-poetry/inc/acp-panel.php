<?php

/*
 * Accessible Poetry Settings
 */
function acp_admin_assets($hook) {
	wp_register_style( 'acp-admin-style', plugins_url('accessible-poetry/assets/css/acp-admin-style.css') );
	wp_enqueue_style( 'acp-admin-style' );
	
}
add_action( 'admin_enqueue_scripts', 'acp_admin_assets' );

/*
 * Accessible Poetry Settings
 */
class Accessible_Poetry {
	
    private $options;

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
    }

    public function add_plugin_page() {
	    add_menu_page(
		    'custom menu title',
			'Accessible Poetry',
			'manage_options',
			'accessible-poetry',
			array( $this, 'create_admin_page' ),
			'dashicons-yes',
			72
	    );
    }

    public function create_admin_page() {

        $this->options = get_option( 'accessible_poetry' );
        ?>
        <div id="accessible-poetry-panel" class="wrap">
            <h1>Accessible Poetry <small>by Amit Moreno</small></h1>           
            <form method="post" action="options.php">
            <?php
                settings_fields( 'acp_group' );   
                do_settings_sections( 'accessible-poetry' );
                submit_button(); 
            ?>
            </form>
        </div>
<script type="text/javascript">
jQuery(document).ready(function($) {
	$("#declaration").parent().parent().next().hide();
	
	$('#declaration').click(function() {
  		$("#declaration").parent().parent().next().fadeToggle(400);
	});
	if ($('#declaration:checked').val() !== undefined) {
		$("#declaration").parent().parent().next().show();
	}
	
	$("#contact").parent().parent().next().hide();
	
	$('#contact').click(function() {
  		$("#contact").parent().parent().next().fadeToggle(400);
	});
	if ($('#contact:checked').val() !== undefined) {
		$("#contact").parent().parent().next().show();
	}
});
</script>
        <?php
    }

    public function page_init() {        
        register_setting(
            'acp_group',
            'accessible_poetry',
            array( $this, 'sanitize' )
        );
		
		// sections
		
        add_settings_section(
            'acp_lauguage',
            __('Language', 'acp'),
            array( $this, 'print_section_info' ),
            'accessible-poetry'
        );  
        
        add_settings_section(
            'acp_images',
            __('Images', 'acp'),
            array( $this, 'print_section_info' ),
            'accessible-poetry'
        );
        
        add_settings_section(
            'acp_links',
            __('Links', 'acp'),
            array( $this, 'print_section_info' ),
            'accessible-poetry'
        );
        
        add_settings_section(
            'acp_titles',
            __('Titles', 'acp'),
            array( $this, 'print_section_info' ),
            'accessible-poetry'
        );
        
        add_settings_section(
            'acp_toolbar',
            __('Toolbar', 'acp'),
            array( $this, 'print_toolbar_info' ),
            'accessible-poetry'
        );
        
        add_settings_section(
            'acp_toolbar_additional',
            __('Toolbar Additional Buttons', 'acp'),
            array( $this, 'print_section_info' ),
            'accessible-poetry'
        );
        
        add_settings_section(
            'acp_fontsizer',
            __('Font Sizer', 'acp'),
            array( $this, 'print_section_info' ),
            'accessible-poetry'
        );
        
        add_settings_section(
            'acp_skiplinks',
            __('Skiplinks', 'acp'),
            array( $this, 'print_skiplinks_info' ),
            'accessible-poetry'
        );
		
		// fields
		
        add_settings_field(
            'html_lang',
            __('Add Language Attribute to the <html> tag', 'acp'),
            array( $this, 'html_lang_callback' ),
            'accessible-poetry',
            'acp_lauguage'           
        );      

        add_settings_field(
            'image_alt',
            __('Add empty Alt attribute to images without Alt', 'acp'),
            array( $this, 'image_alt_callback' ), 
            'accessible-poetry', 
            'acp_images'
        ); 
        
        add_settings_field(
            'aria_label',
            __('Replace all title attributes to aria-label on links', 'acp'),
            array( $this, 'aria_label_callback' ), 
            'accessible-poetry', 
            'acp_links'
        ); 
        
        add_settings_field(
            'link_underline',
            __('Add underline to all links', 'acp'),
            array( $this, 'link_underline_callback' ), 
            'accessible-poetry', 
            'acp_links'
        );
        
        add_settings_field(
            'link_outline',
            __('Add outline to all links & buttons', 'acp'),
            array( $this, 'link_outline_callback' ), 
            'accessible-poetry', 
            'acp_links'
        );
        
        add_settings_field(
            'low_titles',
            __('Replace all low title tags (h4, h5, h6) with h3 title tag', 'acp'),
            array( $this, 'low_titles_callback' ), 
            'accessible-poetry', 
            'acp_titles'
        );
        
        add_settings_field(
            'titles_tabindex',
            __('Add tabindex attribute to all the titles', 'acp'),
            array( $this, 'titles_tabindex_callback' ), 
            'accessible-poetry', 
            'acp_titles'
        );
        
        add_settings_field(
            'disable_mobile_toolbar',
            __('Disable toolbar for mobile', 'acp'),
            array( $this, 'disable_mobile_toolbar_callback' ), 
            'accessible-poetry', 
            'acp_toolbar'
        );
        
        add_settings_field(
            'hide_fontsizer',
            __('Hide the buttons that change the font size', 'acp'),
            array( $this, 'hide_fontsizer_callback' ), 
            'accessible-poetry', 
            'acp_toolbar'
        );
        
        add_settings_field(
            'hide_contrast',
            __('Hide the buttons that change the contrast', 'acp'),
            array( $this, 'hide_contrast_callback' ), 
            'accessible-poetry', 
            'acp_toolbar'
        );
        
        add_settings_field(
            'hide_underline',
            __('Hide the button that add underline to links', 'acp'),
            array( $this, 'hide_underline_callback' ), 
            'accessible-poetry', 
            'acp_toolbar'
        );
        
        add_settings_field(
            'hide_linkmark',
            __('Hide the button that mark the links', 'acp'),
            array( $this, 'hide_linkmark_callback' ), 
            'accessible-poetry', 
            'acp_toolbar'
        );
        
        add_settings_field(
            'hide_readable',
            __('Hide the button that change the font to readable', 'acp'),
            array( $this, 'hide_readable_callback' ), 
            'accessible-poetry', 
            'acp_toolbar'
        );
        
        add_settings_field(
            'hide_animation',
            __('Hide the button that disable the animations', 'acp'),
            array( $this, 'hide_animation_callback' ), 
            'accessible-poetry', 
            'acp_toolbar'
        );
        
        add_settings_field(
            'declaration',
            __('Add Accessibility Declaration Button', 'acp'),
            array( $this, 'declaration_callback' ), 
            'accessible-poetry', 
            'acp_toolbar_additional'
        );
        add_settings_field(
            'declaration_link',
            __('Add the link for the Accessibility Declaration', 'acp'),
            array( $this, 'declaration_link_callback' ), 
            'accessible-poetry', 
            'acp_toolbar_additional'
        );
        
        add_settings_field(
            'contact',
            __('Add Contact Button', 'acp'),
            array( $this, 'contact_callback' ), 
            'accessible-poetry', 
            'acp_toolbar_additional'
        );
        
        add_settings_field(
            'contact_link',
            __('Add the link for the Contact Button', 'acp'),
            array( $this, 'contact_link_callback' ), 
            'accessible-poetry', 
            'acp_toolbar_additional'
        );
        
        add_settings_field(
            'skiplinks_activate',
            __('Activate skiplinks', 'acp'),
            array( $this, 'skiplinks_callback' ), 
            'accessible-poetry', 
            'acp_skiplinks'
        );
        
        add_settings_field(
            'skiplinks_home',
            __('Activate different skiplinks for home page', 'acp'),
            array( $this, 'skiplinks_home_callback' ), 
            'accessible-poetry', 
            'acp_skiplinks'
        );
        
        add_settings_field(
            'fontsizer_include',
            __('Include additional tags, classes & id\'s with the font-size changer (separate with a comma)', 'acp'),
            array( $this, 'fontsizer_include_callback' ), 
            'accessible-poetry', 
            'acp_fontsizer'
        );
        
        add_settings_field(
            'fontsizer_exclude',
            __('Exclude additional tags, classes & id\'s with the font-size changer (separate with a comma)', 'acp'),
            array( $this, 'fontsizer_exclude_callback' ), 
            'accessible-poetry', 
            'acp_fontsizer'
        );
            
    }

    public function sanitize( $input ) {
        $new_input = array();
        
        if( isset( $input['html_lang'] ) )
            $new_input['html_lang'] = absint( $input['html_lang'] );

        if( isset( $input['image_alt'] ) )
            $new_input['image_alt'] = absint( $input['image_alt'] );
            
        if( isset( $input['aria_label'] ) )
            $new_input['aria_label'] = absint( $input['aria_label'] );

        if( isset( $input['link_underline'] ) )
            $new_input['link_underline'] = absint( $input['link_underline'] );
            
        if( isset( $input['link_outline'] ) )
            $new_input['link_outline'] = sanitize_text_field( $input['link_outline'] );
            
        if( isset( $input['low_titles'] ) )
            $new_input['low_titles'] = absint( $input['low_titles'] );
            
        if( isset( $input['titles_tabindex'] ) )
            $new_input['titles_tabindex'] = absint( $input['titles_tabindex'] );
            
        if( isset( $input['disable_mobile_toolbar'] ) )
            $new_input['disable_mobile_toolbar'] = absint( $input['disable_mobile_toolbar'] );
            
        if( isset( $input['hide_fontsizer'] ) )
            $new_input['hide_fontsizer'] = absint( $input['hide_fontsizer'] );
            
        if( isset( $input['hide_contrast'] ) )
            $new_input['hide_contrast'] = absint( $input['hide_contrast'] );
            
        if( isset( $input['hide_underline'] ) )
            $new_input['hide_underline'] = absint( $input['hide_underline'] );
            
        if( isset( $input['hide_linkmark'] ) )
            $new_input['hide_linkmark'] = absint( $input['hide_linkmark'] );
            
        if( isset( $input['hide_readable'] ) )
            $new_input['hide_readable'] = absint( $input['hide_readable'] );
            
        if( isset( $input['hide_animation'] ) )
            $new_input['hide_animation'] = absint( $input['hide_animation'] );
            
        if( isset( $input['skiplinks_activate'] ) )
            $new_input['skiplinks_activate'] = absint( $input['skiplinks_activate'] );
            
        if( isset( $input['skiplinks_home'] ) )
            $new_input['skiplinks_home'] = absint( $input['skiplinks_home'] );
            
        if( isset( $input['declaration'] ) )
            $new_input['declaration'] = absint( $input['declaration'] );
            
        if( isset( $input['declaration_link'] ) )
           	$new_input['declaration_link'] = sanitize_text_field( $input['declaration_link'] );
            
        if( isset( $input['contact'] ) )
            $new_input['contact'] = absint( $input['contact'] );
            
        if( isset( $input['contact_link'] ) )
           	$new_input['contact_link'] = sanitize_text_field( $input['contact_link'] );
           	
        if( isset( $input['fontsizer_include'] ) )
           	$new_input['fontsizer_include'] = sanitize_text_field( $input['fontsizer_include'] );
           	
        if( isset( $input['fontsizer_exclude'] ) )
           	$new_input['fontsizer_exclude'] = sanitize_text_field( $input['fontsizer_exclude'] );


        return $new_input;
    }

    public function print_section_info() {
        //print 'Enter your settings below:';
    }
    public function print_toolbar_info() {
        print '<p class="acp-section-info">' . __('To display the toolbar add the next function right after the opening of the <body> tag: ', 'acp') . '<br><code>&lt;?php if(function_exists(\'acp_toolbar\') ) { acp_toolbar(); }?&gt;</code></p>';
    }
    public function print_skiplinks_info() {
        print '<p class="acp-section-info">' . __('To display the skiplinks add links to the skiplinks menu\'s and then add the next function right after the opening of the <body> tag: ', 'acp') . '<br><code>&lt;?php if(function_exists(\'acp_skiplinks\') ) { acp_skiplinks(); }?&gt;</code></p>';
    }

    public function html_lang_callback() {
        printf(
            '<input type="checkbox" id="html_lang" name="accessible_poetry[html_lang]" value="1" ' . checked( '1', isset( $this->options['html_lang'] ), false ) . ' />',
            isset( $this->options['html_lang'] ) ? esc_attr( $this->options['html_lang']) : ''
        );
    }

    public function image_alt_callback() {
        printf(
             '<input type="checkbox" id="image_alt" name="accessible_poetry[image_alt]" value="1" ' . checked( '1', isset( $this->options['image_alt'] ), false ) . ' />',
            isset( $this->options['image_alt'] ) ? esc_attr( $this->options['image_alt']) : ''
        );
    }
    
    public function aria_label_callback() {
        printf(
             '<input type="checkbox" id="aria_label" name="accessible_poetry[aria_label]" value="1" ' . checked( '1', isset( $this->options['aria_label'] ), false ) . ' />',
            isset( $this->options['aria_label'] ) ? esc_attr( $this->options['aria_label']) : ''
        );
    }
    
    public function link_underline_callback() {
        printf(
             '<input type="checkbox" id="link_underline" name="accessible_poetry[link_underline]" value="1" ' . checked( '1', isset( $this->options['link_underline'] ), false ) . ' />',
            isset( $this->options['link_underline'] ) ? esc_attr( $this->options['link_underline']) : ''
        );
    }
    
    public function link_outline_callback() {
	    if( $this->options['link_outline'] == 'none' ) {
		    $none = 'checked';
		    $red = '';
		    $blue = '';
	    }
	    elseif( $this->options['link_outline'] == 'red' ) {
		    $none = '';
		    $red = 'checked';
		    $blue = '';
	    }
	    elseif( $this->options['link_outline'] == 'blue' ) {
		    $none = '';
		    $red = '';
		    $blue = 'checked';
	    }
		
        printf(
            '<input type="radio" id="link_outline" name="accessible_poetry[link_outline]" value="none" ' . $none . ' />' . __('-- None --', 'acp') . '<br>' . '
             <input type="radio" id="link_outline" name="accessible_poetry[link_outline]" value="red" ' . $red . ' />' . __('Red', 'acp') . '<br>' . '
             <input type="radio" id="link_outline" name="accessible_poetry[link_outline]" value="blue" ' . $blue . ' />' . __('Blue', 'acp') . '<br>',
            isset( $this->options['link_outline'] ) ? esc_attr( $this->options['link_outline']) : ''
        );
    }
    
    public function low_titles_callback() {
        printf(
             '<input type="checkbox" id="low_titles" name="accessible_poetry[low_titles]" value="1" ' . checked( '1', isset( $this->options['low_titles'] ), false ) . ' />',
            isset( $this->options['low_titles'] ) ? esc_attr( $this->options['low_titles']) : ''
        );
    }
    
    public function titles_tabindex_callback() {
        printf(
             '<input type="checkbox" id="titles_tabindex" name="accessible_poetry[titles_tabindex]" value="1" ' . checked( '1', isset( $this->options['titles_tabindex'] ), false ) . ' />',
            isset( $this->options['titles_tabindex'] ) ? esc_attr( $this->options['titles_tabindex']) : ''
        );
    }
    
    public function disable_mobile_toolbar_callback() {
        printf(
             '<input type="checkbox" id="disable_mobile_toolbar" name="accessible_poetry[disable_mobile_toolbar]" value="1" ' . checked( '1', isset( $this->options['disable_mobile_toolbar'] ), false ) . ' />',
            isset( $this->options['disable_mobile_toolbar'] ) ? esc_attr( $this->options['disable_mobile_toolbar']) : ''
        );
    }
    
    public function hide_fontsizer_callback() {
        printf(
             '<input type="checkbox" id="hide_fontsizer" name="accessible_poetry[hide_fontsizer]" value="1" ' . checked( '1', isset( $this->options['hide_fontsizer'] ), false ) . ' />',
            isset( $this->options['hide_fontsizer'] ) ? esc_attr( $this->options['hide_fontsizer']) : ''
        );
    }
    
    public function hide_contrast_callback() {
        printf(
             '<input type="checkbox" id="hide_contrast" name="accessible_poetry[hide_contrast]" value="1" ' . checked( '1', isset( $this->options['hide_contrast'] ), false ) . ' />',
            isset( $this->options['hide_contrast'] ) ? esc_attr( $this->options['hide_contrast']) : ''
        );
    }
    
    public function hide_underline_callback() {
        printf(
             '<input type="checkbox" id="hide_underline" name="accessible_poetry[hide_underline]" value="1" ' . checked( '1', isset( $this->options['hide_underline'] ), false ) . ' />',
            isset( $this->options['hide_underline'] ) ? esc_attr( $this->options['hide_underline']) : ''
        );
    }
    
    public function hide_linkmark_callback() {
        printf(
             '<input type="checkbox" id="hide_linkmark" name="accessible_poetry[hide_linkmark]" value="1" ' . checked( '1', isset( $this->options['hide_linkmark'] ), false ) . ' />',
            isset( $this->options['hide_linkmark'] ) ? esc_attr( $this->options['hide_linkmark']) : ''
        );
    }
    
    public function hide_readable_callback() {
        printf(
             '<input type="checkbox" id="hide_readable" name="accessible_poetry[hide_readable]" value="1" ' . checked( '1', isset( $this->options['hide_readable'] ), false ) . ' />',
            isset( $this->options['hide_readable'] ) ? esc_attr( $this->options['hide_readable']) : ''
        );
    }
    public function hide_animation_callback() {
        printf(
             '<input type="checkbox" id="hide_animation" name="accessible_poetry[hide_animation]" value="1" ' . checked( '1', isset( $this->options['hide_animation'] ), false ) . ' />',
            isset( $this->options['hide_animation'] ) ? esc_attr( $this->options['hide_animation']) : ''
        );
    }
    public function skiplinks_callback() {
        printf(
             '<input type="checkbox" id="skiplinks_activate" name="accessible_poetry[skiplinks_activate]" value="1" ' . checked( '1', isset( $this->options['skiplinks_activate'] ), false ) . ' />',
            isset( $this->options['skiplinks_activate'] ) ? esc_attr( $this->options['skiplinks_activate']) : ''
        );
    }
    public function skiplinks_home_callback() {
        printf(
             '<input type="checkbox" id="skiplinks_home" name="accessible_poetry[skiplinks_home]" value="1" ' . checked( '1', isset( $this->options['skiplinks_home'] ), false ) . ' />',
            isset( $this->options['skiplinks_home'] ) ? esc_attr( $this->options['skiplinks_home']) : ''
        );
    }
    
    public function declaration_callback() {
        printf(
             '<input type="checkbox" id="declaration" name="accessible_poetry[declaration]" value="1" ' . checked( '1', isset( $this->options['declaration'] ), false ) . ' />',
            isset( $this->options['declaration'] ) ? esc_attr( $this->options['declaration']) : ''
        );
    }
    
    public function declaration_link_callback() {
        printf(
             '<input type="text" id="declaration_link" name="accessible_poetry[declaration_link]" value="%s" />',
            isset( $this->options['declaration_link'] ) ? esc_attr( $this->options['declaration_link']) : ''
        );
    }
    
    public function contact_callback() {
        printf(
             '<input type="checkbox" id="contact" name="accessible_poetry[contact]" value="1" ' . checked( '1', isset( $this->options['contact'] ), false ) . ' />',
            isset( $this->options['contact'] ) ? esc_attr( $this->options['contact']) : ''
        );
    }
    
    public function contact_link_callback() {
        printf(
             '<input type="text" id="contact_link" name="accessible_poetry[contact_link]" value="%s" />',
            isset( $this->options['contact_link'] ) ? esc_attr( $this->options['contact_link']) : ''
        );
    }
    
    public function fontsizer_include_callback() {
	    printf(
             '<input type="text" id="fontsizer_include" name="accessible_poetry[fontsizer_include]" value="%s" />',
            isset( $this->options['fontsizer_include'] ) ? esc_attr( $this->options['fontsizer_include']) : ''
        );
    }
    
    public function fontsizer_exclude_callback() {
	    printf(
             '<input type="text" id="fontsizer_exclude" name="accessible_poetry[fontsizer_exclude]" value="%s" />',
            isset( $this->options['fontsizer_exclude'] ) ? esc_attr( $this->options['fontsizer_exclude']) : ''
        );
    }
    
}

if( is_admin() )
    $accessible_poetry = new Accessible_Poetry();