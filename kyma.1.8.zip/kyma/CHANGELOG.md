###Verision 1.8
* Date format issue fixed.
* HTML formating issue fixed Like: list, table etc.
* Some other minor bug fixed.
###Verision 1.7
* Minor bug fixed.
###Verision 1.6
* Unused tags removed from style.css.
* Now "load more posts" button working according to category.
* Text logo linkable issue fixed.
* Home page section reorder feature added in customizer.
* Sidebar and footer widget styling issue fixed.
* Slider text in boxed width indent properly.
* Now category, archive, tag, author posts working properly.
* Extra content section title setting added in customizer.
* Some other styling issue fixed.
###Verision 1.5
* Demo home page removed.
* Update font-awesome library.
* Update kirki customizer library.
* In extra content section content field replace by editor.
* Some minor bug fixed.
###Verision 1.4.9
* Show home blog post according category.
* Add extra content section on home page template just Go to Dashboard Admin Panel >> Appearance >> Customize >> Kyme Options >> Extra Content options >> Show Extra Content on Home.
* Kirki Customizer compatible with child-theme.
* update font-awesome library files.
* Minor bug fixed.
###Verision 1.4.8
* Comatible with WordPress.org language packs.
###Verision 1.4.7
* Top bar font color added
* Typography added
* Custom Css Field Added
* Header Section removed
* Screenshot updated
###Version 1.4.6
* Demo Home Page added.
* Header contact information issue fixed.
* Header topbar background color option added.
* Header background color option added.
* Header text color option added.
###Version 1.4.5
* Customizer saving issue solved.
###Version 1.4.4
* Some Bugs Fixed.
###Version 1.4.3
* Menu navigation issue in mobile view fixed.
###Version 1.4.2
* Page 404 error Fixed.
###Version 1.4.1
* Footer background color option added.
* RTL Support added.
###Version 1.4
* Now only using one text domain 'kyma'.
###Version 1.3
* All comments in pages is enabled.
* Remove white-spaces and proper code indent. 
* Minor issue fixed.
###Version 1.2
* Update New Customizer
* Some minor issues has been fixed
###Version 1.1
* Made some changes in readme.txt file.
* Changed text domain and filtered all files.
###Version 1.0.4
* First public release